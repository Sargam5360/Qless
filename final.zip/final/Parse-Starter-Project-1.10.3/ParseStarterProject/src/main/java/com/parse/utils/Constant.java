package com.parse.utils;

import com.parse.data.DataProduts;

import java.util.ArrayList;

/**
 * Created by rethinavel on 26/11/15.
 */
public class Constant {

    public static ArrayList<DataProduts> sSelectedItemsAl = new ArrayList<DataProduts>();

}
